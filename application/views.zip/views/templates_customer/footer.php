<footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright © 2020 Company Name - Template by: <a href="https://www.phpjabbers.com/">PHPJabbers.com</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>

  


    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url('assets/assets_shop')?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url('assets/assets_shop')?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="<?php echo base_url('assets/assets_shop')?>/js/custom.js"></script>
    <script src="<?php echo base_url('assets/assets_shop')?>/js/owl.js"></script>
  </body>

</html>
